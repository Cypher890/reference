module.exports.PORT=3000
module.exports.TEMPLATE_ID_LOGIN="5ff8328cdcf45e143f3638ce"
module.exports.AUTH_KEY="301700A1MKcYDOCIh5dbbd02b"
module.exports.TEMPLATE_ID_REG="5ff828a2690aff09103dfaca"
module.exports.TEMP_JWT = "5ff446850b7c693f220cc8475ff4261633ad9b29155b22b3"
module.exports.MONGO_URI="mongodb://127.0.0.1:27017"