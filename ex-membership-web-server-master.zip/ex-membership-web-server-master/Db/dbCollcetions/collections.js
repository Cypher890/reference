const users = "users";
const faqs = "faqs";
const challenges = "challenges";
const messages ="messages";
const suggestions = "suggestions"
const kits = "kits"
module.exports = {users,faqs,challenges,messages,suggestions,kits};