const express = require('express');
const cors = require('cors');
const port = require('./config/port');
const router = require('./routes');
const { createMongoDbConnection } = require('../../Db/config');
const app = express();
const jsonErrHandler = require("../../libs/middleware/jsonErrorHandler")
const jwtChecker = require("../../libs/middleware/jwtMiddleWare")
var fileUpload = require('express-fileupload');



/**
 * ? =========MIDDLEWARE======================
 */
// Cross Origin Resource Sharing 
app.use(cors());
// Parse JSON 
app.use(express.json());
//Parse urlencoded payloads
app.use(express.urlencoded({ extended: true }));
// For throwing Error if JSON not valid 
app.use(jsonErrHandler);


//setting public folder as static
app.use(express.static(__dirname + '/public'));

//express-fileupload module
app.use(fileUpload({
  limits: { fileSize: 2 * 1024 * 1024 }, //file size limitted to 2MB
  files:1,
  abortOnLimit: true,
  // limitHandler:(req,res,next)=>{
  //   console.log("handler fired")
  //   res.json({status: 413, msg: 'File size is too Large'})
  //   res.end()
  // }
}))

// 404 setting
// app.use((req,res)=>{
//   console.log(req.originalUrl)
//  if(req.originalUrl === '/admin' 
//  || req.originalUrl === '/admin/*' 
//  || req.originalUrl === '/techlead' 
//  || req.originalUrl === '/techlead/*' 
//  || req.originalUrl === '/user' 
//  || req.originalUrl === '/user/*' 
//  || req.originalUrl === '/common' 
//  || req.originalUrl === '/common/*' ){
//   next()
//  }else{
//    console.error("404: Are you Lost Kid?");
//    res.json({status: 404, msg: '404: Are you Lost Kid?'})
//  }
// })

//JWT checker Middleware 

app.use(jwtChecker);
/**
 * ? ===========ROUTER=====================
 */
app.use('/', router);





/**
 * ? =====MONGODB CONNECTION AND LISTENER====
 */

try {
  createMongoDbConnection();
  app.listen(port, function () {
    console.log(`Http Service is running on port ${port}`);
  });
} catch (err) {
  // Error Handler function goes here
  console.log(err);
}
