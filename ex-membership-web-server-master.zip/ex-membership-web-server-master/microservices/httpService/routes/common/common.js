const router = require('express').Router();
const controller = require("../../../../libs/controllers/common/controller/index");
// const {userGetValidation,validate } = require("../../../../libs/controllers/Admin/validator/validator")
const { profileUpdateRule, challengeValidationRule, commonValidateResult, userCreateRules, userEditRules, userGetValidation } = require("../../../../libs/controllers/common/validator/validator")
const { imageUpload, challengesImageUpload, faqImageUpload } = require('../../../../libs/controllers/common/controller/fileupload');

const { jsonParser } = require('../../../../libs/middleware/jsonParser')


//file uploading

router.post("/imageupload", controller.imageUpload)

//update profile

router.put("/profileupdate", profileUpdateRule(), commonValidateResult, controller.profileUpdate)

//image delete route

router.patch("/profileupdate", controller.deleteProfilePic)

//settings 

router.get("/settings", controller.settings)

//Dashboard Data

router.get("/dashboard", controller.settings)

//Get all Challenges
router.get("/challenges", controller.getChallenges)

//Get all FAQ 
router.get("/faqs", controller.getFaq)

//Create FAQ  faqValidation() validate,
router.post("/faq", controller.createFaq)

//faq images post
router.post("/faqimage", faqImageUpload)

//Delete FAQ
router.delete("/faq", controller.deleteFaq)

//Get all users 
router.get("/users", controller.getAllUser)

//Delete user 
router.delete("/users", controller.deleteUser)

//Banned user 
router.patch("/users", controller.bannedUser)

//Premium user 
router.post("/premiummember", controller.premiumMember)

//Edit user details userGetValidation
router.put("/users", userEditRules(), commonValidateResult, controller.editUser)

//  Add user 
router.post("/add_user", userGetValidation(), commonValidateResult, controller.addUser)

//Create Challenge
router.post("/challenges", challengesImageUpload, controller.createChallenge)

//Update challenge
router.put("/challenges", jsonParser, challengeValidationRule(), commonValidateResult, controller.editChallenge)

//Delete Challenge
router.delete("/challenges", controller.deleteChallenge)


module.exports = router;