const router = require('express').Router();
const {userCreateRules,userEditRules,userGetValidation,
  otpValidation,faqValidation,validate } = require("../../../../libs/controllers/Admin/validator/validator")
  const {challengeValidationRule,commonValidateResult} = require("../../../../libs/controllers/common/validator/validator")
const controller = require("../../../../libs/controllers/Admin/controller/");
const {adminChecker} = require("../../../../libs/middleware/userRolecheck")

//Userrole checking
router.use(adminChecker)

// Get details for dashboard 
router.get("/dashboard",controller.getDashboard)

// //Get all users 
// router.get("/users",controller.getAllUser)

// Create user Route

router.post("/users",userCreateRules(),validate,controller.createUser)

// //Edit user details userGetValidation
// router.put("/users",userEditRules(),validate,controller.editUser)

// //Delete user 
// router.delete("/users",controller.deleteUser)

//Get all FAQ 
router.get("/faq",controller.getFaq) //move to common

//Create FAQ 
router.post("/faq",faqValidation(),validate,controller.createFaq) //move to common

//Update FAQ 
router.put("/faq",faqValidation(),validate,controller.editFaq) //move to common

// //Delete FAQ
// router.delete("/faq",controller.deleteFaq) //move to common

//Get all Challenges
router.get("/challenges",controller.getChallenges) //move to common

//Create Challenge
router.post("/challenges",controller.createChallenge) //move to common

//Update challenge
router.put("/challenges",challengeValidationRule(),commonValidateResult,controller.editChallenge) //move to common

//Delete Challenge
router.delete("/challenges",controller.deleteChallenge) //move to common

// send_otp in user

router.post('/send_otp',userGetValidation(), validate,controller.sendOtp);

//Verify OTP route 

router.post('/verify',otpValidation(),validate,controller.verifyOtp);

//Resend OTP 

router.post('/resend_otp',userGetValidation(), validate,controller.reSend);

// //  Add user 

// router.post("/add_user",userGetValidation(), validate,controller.addUser)



module.exports = router;