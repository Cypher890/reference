const router = require('express').Router();
//const {getMongoDbConnection} = require('../../../../Db/config');
const controller = require("../../../../libs/controllers/User/controller/loginRegisterController")
const { userGetValidation, otpValidation, validate, userCreateRules } = require("../../../../libs/controllers/User/validator/validator")
const { imageUpload } = require('../../../../libs/controllers/common/controller/fileupload');
const { jsonParser } = require('../../../../libs/middleware/jsonParser')


//User signup

router.post("/register", jsonParser, userCreateRules(), validate, imageUpload, controller.registerSubmit)

//Send OTP

router.post('/send_otp', controller.sendOtp);

//Verify OTP route 

router.post('/verify', otpValidation(), validate, controller.verifyOtp);

// Register OTP 

router.post("/register_otp", controller.registerOTP)

// Register Verify and otp 

router.post("/register_verify", otpValidation(), validate, controller.registerVerify)

// Register submit 

router.post("/register_submit", otpValidation(), validate, controller.registerSubmit)

// payment 

router.post("/payment", controller.payment)


module.exports = router;
