const router = require('express').Router();
const controller = require("../../../../libs/controllers/TechLead/controller/");
const { userCreateRules, userEditRules, userGetValidation,
    otpValidation, faqValidation, validate,
    SuggestionValidation } = require("../../../../libs/controllers/TechLead/validator/validator")
const { challengeValidationRule, commonValidateResult } = require("../../../../libs/controllers/common/validator/validator")

const { techleadChecker } = require("../../../../libs/middleware/userRolecheck")
const { jsonParser } = require('../../../../libs/middleware/jsonParser')
const { imageUpload, challengesImageUpload, faqImageUpload } = require('../../../../libs/controllers/common/controller/fileupload');

//userRole checker, here we verify that user is techlead or techsupport 
router.use(techleadChecker);

//Login TechLead
// router.post('/login', userGetValidatioimageFileNamen(),validate,controller.loginUser);

//Get all Users
router.get("/users", controller.getAllUser)

// Create user 
router.post("/users", userCreateRules(), validate, controller.createUser)

//Edit user details 
router.put("/users", userEditRules(), validate, controller.editUser)

//Delete user 
router.delete("/users", controller.deleteUser)

// //Get all FAQ 
// router.get("/faq", controller.getFaq)

// //Create FAQ  faqValidation() validate,
// router.post("/faq", controller.createFaq)

// //faq images post
// router.post("/faqimage", faqImageUpload)


//Update FAQ 
router.put("/faq", faqValidation(), validate, controller.editFaq)

//Delete FAQ
router.delete("/faq", controller.deleteFaq)

// //Get all Challenges
// router.get("/challenges", controller.getChallenges)

// //Create Challenge
// router.post("/challenges", challengesImageUpload, controller.createChallenge)

// //Update challenge
// router.put("/challenges", jsonParser, challengeValidationRule(), commonValidateResult, controller.editChallenge)

// //Delete Challenge
// router.delete("/challenges", controller.deleteChallenge)

// send_otp in user

router.post('/send_otp', userGetValidation(), validate, controller.sendOtp);

//Verify OTP route 

router.post('/verify', otpValidation(), validate, controller.verifyOtp);

//Resend OTP 

router.post('/resend_otp', userGetValidation(), validate, controller.reSend);

//add new user with phone number only

router.post("/add_user", userGetValidation(), validate, controller.addUser)

//get dashboard or Questions windows

router.get("/dashboard", controller.getDashboard)

//create suggestion

router.post("/savesuggestions", SuggestionValidation(), validate, controller.createSuggestion)

// get all suggesstion

router.get("/getsuggestions", controller.getAllSuggestions)

// create kit
router.post("/kit", controller.createKit)

//get all kits

router.get("/kit", controller.getKit)

//update kit

router.put("/kit", controller.editKit)

//delete kit

router.delete("/kit", controller.deleteKit)

//get suggesstion and challenges

router.get("/getsuggestionsandkits", controller.getAllKitsAndSuggestions)






module.exports = router;
