const router = require('express').Router();

router.use("/admin",require("./admin/admin"))
router.use("/techlead",require("./techLead/techLead"))
router.use("/user",require("./users/users"))
router.use("/common",require("./common/common"))



module.exports = router;
