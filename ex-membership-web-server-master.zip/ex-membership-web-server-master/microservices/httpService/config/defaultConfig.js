module.exports.defaultProfilePic = "/images/defaultProfile/person-icon_9.svg";

// module.exports.serverUrl = "http://bf98058d3257.ngrok.io"

module.exports.serverUrl = "https://chat.sreeganesh.co"

// module.exports.serverUrl = "http://localhost:3001"


///////////////////////////////////***************************Environment**********************/////////////////////////////////

module.exports.environment = 'development'
// module.exports.environment = 'production'

