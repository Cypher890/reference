const router = require('express').Router();
const {getMongoDbConnection} =require("../../../Db/config")
router.get("/",async(req,res)=>{
    const db = await getMongoDbConnection();
    res.json({msg:"Hello World"})
})


module.exports=router