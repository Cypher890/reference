const express = require('express');
const path = require('path');
const cors = require('cors');
const app = express();
const server = require('http').createServer(app);
const SocketIOFileUpload = require('socketio-file-upload');
const redis = require("socket.io-redis");
const fs = require('fs');
const FileType = require('file-type');
const { v4: uuid } = require('uuid');
const moveFile = require('move-file');
const arrayMove = require('array-move')


const { createMongoDbConnection, getMongoDbConnection } = require('../../Db/config');
const COLLECTION = require('../../Db/dbCollcetions/collections');
const { jwtVerify } = require('../../libs/helpers/jwtService/jwtService');
const { msgFormatter, urlFormatter } = require('../../libs/helpers/socketService/messageFormater');
const {
	userJoinRoom,
	userLeft,
	getAllRooms,
	userFindRoom,
	techJoinRoom,
	techLeftRoom,
	techRoomFind,
	notificationController,
	solvedController,
	deleteTechFromRoom,
	updatingTechInRoom,
} = require('../../libs/helpers/socketService/socketService');
const port = require('./config/port');
const router = require('./sockets/index');

let fileUploadingKeys = [];

app.use(cors());
app.use(SocketIOFileUpload.router);

const io = require('socket.io')(server, {
	cors: {
		origin: "*",
	}
});
io.adapter(redis({ host: "localhost", port: 6379 }));


app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (req, res) => {
	res.send('Socket Server is working');
});
try {
	io
		.use(async function (socket, next) {
			if (socket.handshake.query && socket.handshake.query.token) {
				console.log('Inside');
				const payload = await jwtVerify(socket.handshake.query.token);
				console.log(payload, "-----------------------------------------payload")
				socket['payload'] = payload;
				next();
			} else {
				next(new Error('Authentication error'));
			}
		})
		.on('connection', async (socket) => {

			let lastUpdateRoom = await userFindRoom(socket.payload.phoneNumber);
			console.log(lastUpdateRoom, "fdfgdfgdfgdg");

			socket.emit('userinfo', {
				phone: socket.payload.phoneNumber,
				userType: socket.payload.userType,
				id: socket.payload.id,
				room: socket.payload.phoneNumber + socket.payload.userType,
				markAsSolved: socket.payload.markAsSolved,
				buttonPressedByTechy: lastUpdateRoom ? lastUpdateRoom.buttonPressedByTechy : undefined,
				username: socket.payload.username,
				profilePic: lastUpdateRoom ? lastUpdateRoom.profilePic : socket.payload.profilePic
			});
			//IF PAYLOAD USER TYPE IS USER
			if (socket.payload.userType === 'USER' || socket.payload.userType === 'EXCLUSIVE') {
				console.log('[PALOAd ]' + JSON.stringify(socket.payload));
				console.log('USER CONNECTED');
				console.log(`${socket.payload.phoneNumber} is connected to socket`);
				console.log('USER CONNECTED');
				//THEN CREATE ROOM WITH SOCKET_ID AND PHONE LOCALLY
				//CHANGE STATUS OF ROOM TO BE TRUE
				const room = await userJoinRoom(socket);
				console.log(`USER ROOM CREATED `);
				console.log(room);
				console.log(`USER ROOM CREATED`);
				// const rooms = await getAllRooms();
				// io.emit('rooms', rooms);
				//JOIN THAT PERSON IN THAT ROOM
				socket.join(room);
				console.log(`${room} user join room=========================== `);
				try {
					const db = await getMongoDbConnection();
					const collection = db.collection(COLLECTION.messages);
					const messages = await collection.find({ room: room }).sort({ _id: -1 }).limit(50).toArray();
					// console.log("old_messages===============", messages, "=================old_messages");
					io.to(room).emit('old_message_for_user', messages.reverse());
				} catch (error) {
					console.log(error);
				}
				//SEND OLD DATA
			}
			if (socket.payload.userType === 'TECHLEAD' || socket.payload.userType === 'TECHSUPPORT') {
				console.log('TECHLEAD/TECHSUPPORT CONNECTED');
				console.log(`${socket.payload.phoneNumber} is connected to socket `);
				console.log('TECHLEAD/TECHSUPPORT CONNECTED');

				// WHEN TECH CONNECTS SEND THEM ALL THE ROOMS
				const rooms = await getAllRooms();
				socket.emit('rooms', rooms);
				//WHEN TECH LEAD WANTS TO JOIN A ROOM
				socket.on('join', async (data) => {
					console.log("tech joined room===============", data);
					techJoinRoom(socket, data);

					// const updatedRooms = function
					const updatedRoom = await updatingTechInRoom(socket, data)
					// console.log(updatedRoom, "updatedRoom  $$$$$$$$$$$$$$$$$$$$$$$$");

					console.log('TECHLEAD/TECHSUPPORT JOINED ROOM');
					console.log(`${data.currentRoom.room} JOINED`);
					socket.join(data.currentRoom.room);
					io.emit('rooms', updatedRoom)
					try {
						const db = await getMongoDbConnection();
						const collection = db.collection(COLLECTION.messages);
						const messages = await collection.find({ room: data.currentRoom.room }).sort({ _id: -1 }).limit(10).toArray();
						console.log("old_messages===============", messages.length, "=================old_messages");
						// console.log("old_messages===============", messages, "=================old_messages");
						// io.to(data.currentRoom.room).emit('old_messages', { message: messages.reverse() });
						socket.emit('old_messages', { message: messages.reverse() });
						// console.log(messages.length);
						socket.emit('joinroom', `${socket.payload.phoneNumber} Joined the chat `);
					} catch (error) {
						console.log(error);
					}
				});
			}

			// FILE UPLOAD
			try {
				const uploader = new SocketIOFileUpload();
				uploader.dir = __dirname + '/public/uploads';
				uploader.listen(socket);


				uploader.on('saved', async function (event) {

					// console.log(event, "event===========================")
					let room;
					console.log(socket.payload, "============payload============");
					if (socket.payload.userType === 'USER' || socket.payload.userType === 'EXCLUSIVE') {
						room = await userFindRoom(socket.payload.phoneNumber);
						const { notificationRooms, notificationRoom } = await notificationController(socket.payload);
						io.emit('notification', { room: notificationRooms, currentRoom: notificationRoom });
						console.log(room, "============user + room============");
					} else if (socket.payload.userType === 'TECHLEAD' || socket.payload.userType === 'TECHSUPPORT') {
						room = await techRoomFind(socket.payload);
						room.name = socket.payload.username;
						console.log(room, "============tech room============");
					}
					const newfileName = uuid();
					// const oldPath = __dirname+event.file.pathName;
					const oldPath = path.join(event.file.pathName);
					console.log('----------------------------------100----------', event.file.pathName);
					const type = await FileType.fromFile(event.file.pathName);
					console.log(type, 'type');
					console.log(event.file.meta.fileKey, "=======================================");
					const findKeyIndex = fileUploadingKeys.findIndex(key => key == event.file.meta.fileKey);
					const findKey = fileUploadingKeys.pop(findKeyIndex, 1);
					console.log(findKey, fileUploadingKeys, "--------------------------------------------------------------------");
					if (findKeyIndex >= 0) {
						console.log("founded key");
						uploader.abort(event.file.id, socket)
					}
					if (type.ext === 'jpg' || type.ext === 'png') {
						// const newPath = __dirname+'/public/media/images/' + newfileName + '.' + type.ext;
						const newPath = path.join(__dirname, '/public/media/images/' + newfileName + '.' + type.ext)
						await moveFile(oldPath, newPath).then(async () => {


							console.log("Uploaded Image Processing....,")

							let data = {
								room: room.room,
								username: room.name,
								text: null,
								ext: type.ext,
								url: '/media/images/' + newfileName + '.' + type.ext,
								type: type
							};
							const formattedUrl = urlFormatter(socket, data);
							const db = await getMongoDbConnection();
							const collection = db.collection(COLLECTION.messages);
							const result = collection.insertOne(formattedUrl);
							io.to(room.room).emit('chat', formattedUrl);


						}).catch((err) => {
							console.log(err)
						})
						return;
					} else if (type.ext === 'mp4') {
						const newPath = __dirname + '/public/media/videos/' + newfileName + '.' + type.ext;

						await moveFile(oldPath, newPath).then(async () => {
							console.log("Uploaded mp4 video Processing....,");

							let data = {
								room: room.room,
								username: room.name,
								text: null,
								ext: type.ext,
								url: '/media/videos/' + newfileName + '.' + type.ext,
								type: type
							};
							const formattedUrl = urlFormatter(socket, data);
							const db = await getMongoDbConnection();
							const collection = db.collection(COLLECTION.messages);
							const result = collection.insertOne(formattedUrl);
							io.to(room.room).emit('chat', formattedUrl);

						}).catch((err) => {
							console.log(err)
						})

						return;
					} else if (type.ext === 'mp3' || type.ext === 'webm') {
						const newPath = __dirname + '/public/media/audios/' + newfileName + '.' + type.ext;

						await moveFile(oldPath, newPath).then(async () => {
							console.log("Uploaded mp3 Processing....,")

							let data = {
								room: room.room,
								username: room.name,
								text: null,
								ext: type.ext,
								url: '/media/audios/' + newfileName + '.' + type.ext,
								type: type
							};
							const formattedUrl = urlFormatter(socket, data);
							const db = await getMongoDbConnection();
							const collection = db.collection(COLLECTION.messages);
							const result = collection.insertOne(formattedUrl);
							io.to(room.room).emit('chat', formattedUrl);


						}).catch((err) => {
							console.log(err)
						})

						return;
					}
					console.log(event);
				});
				//FILE UPLOAD
			} catch (error) {
				console.log("socket disconnected " + error);
			}

			//FILE UPLOAD CANCEL
			socket.on('abortUpload', (value) => {
				console.log(value);
				fileUploadingKeys.push(value)
			})

			socket.on('progressBarStatus', (currentRoom) => {
				console.log(currentRoom.room.room, "progress bar status socket event+++++++++++++++++++++++++++++++");
				socket.emit('progressBarShow', { currentRoom: currentRoom.room.room })
			})

			//UPLOAD MP3 VOICE FILE
			try {
				socket.on("voiceUpload", async (voice) => {
					let room;
					if (socket.payload.userType === 'USER' || socket.payload.userType === 'EXCLUSIVE') {
						room = await userFindRoom(socket.payload.phoneNumber);
						const { notificationRooms, notificationRoom } = await notificationController(socket.payload);
						io.emit('notification', { room: notificationRooms, currentRoom: notificationRoom });
					} else if (socket.payload.userType === 'TECHLEAD' || socket.payload.userType === 'TECHSUPPORT') {
						room = await techRoomFind(socket.payload);
					}
					console.log(voice, "mp3 voice", room);
					const newfileName = uuid();
					if (voice) {
						let newPath = __dirname + "/public/media/voice/" + newfileName + ".mp3";
						fs.writeFile(newPath, voice, async (error) => {
							if (error) console.log("file save error", error)
							else {
								let data = {
									room: room.room,
									username: room.name,
									text: null,
									ext: "mp3",
									url: '/media/voice/' + newfileName + '.mp3',
									type: {
										ext: "mp3",
										mime: "audio/mpeg"
									}
								};
								const formattedUrl = urlFormatter(socket, data);
								const db = await getMongoDbConnection();
								const collection = db.collection(COLLECTION.messages);
								const result = collection.insertOne(formattedUrl);
								io.to(room.room).emit('chat', formattedUrl);
							}
						})
					} else {
						console.log("something went wrong in the audio recoding");
					}

				})
			} catch (error) {
				console.log("socket disconnected" + error);
			}


			socket.on('disconnect', async () => {
				//IF USER IF DISCONNECTED THEN CHANGE STATUS OF ROOM
				if (socket.payload.userType === 'USER' || socket.payload.userType === 'EXCLUSIVE') {
					await userLeft(socket.payload);
					
					const rooms = await getAllRooms();
					console.log('=========USER LEFT ROOM==========', rooms);
					io.emit('rooms', rooms);
				} else {
					techLeftRoom(socket);
				}
			});
			socket.on('message_send', async (data) => {
				if (data.roomId) {
					const room = await techRoomFind(socket.payload);
					console.log(room + 'roomData');
					console.log(data, "209,socketserver");
					const message = msgFormatter(socket, data);
					console.log(data.roomId + '[MSG SEND]');
					io.to(data.roomId).emit('chat', message);
					const db = await getMongoDbConnection();
					const collection = db.collection(COLLECTION.messages);
					const result = collection.insertOne(message);
					console.log(message);
				} else {
					console.log(data, "else");
					if (data.isQuestion) {
						const db = await getMongoDbConnection();
						const collection = db.collection(COLLECTION.users);
						const result = await collection.findOneAndUpdate(
							{ "contact.phone": socket.payload.phoneNumber },
							{ "$inc": { "question.count": 1 } });
						console.log(result, "==========================result Count=======================");
					}
					// const room = await userFindRoom(socket.payload.phoneNumber);
					const { notificationRooms, notificationRoom } = await notificationController(socket.payload);
					console.log(notificationRoom, "roooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooom")
					io.emit('notification', { msg: data.message, room: notificationRooms, currentRoom: notificationRoom });
					if (notificationRoom) {
						data['roomId'] = notificationRoom['room'];
						const message = msgFormatter(socket, data);
						console.log(notificationRoom.room + '[MSG SEND]');
						io.to(data.roomId).emit('chat', message);
						const db = await getMongoDbConnection();
						const collection = db.collection(COLLECTION.messages);
						const result = collection.insertOne(message);
						console.log(message, "message");
						// const rooms = await getAllRooms();
					}
				}
			});

			socket.on('typing', async (data) => {
				if (data.roomId) {
					console.log(data, "typing=======================");
					io.to(data.roomId).emit('typings', { msg: data.profilePic, room: data.roomId });
				} else {
					const room = await userFindRoom(socket.payload.phoneNumber);
					console.log(room, "typingss");
					io.to(room.room).emit('user_typing', room);
				}
			});

			socket.on("solvedRoom", async (data) => {
				const { roomArr, roomIndex } = await solvedController(data, socket.payload)
				console.log(roomArr, "==========================updatedRoom1=========================");
				if (data.solvedCount) {
					io.to(roomArr[roomIndex].room).emit('solvedRoom', { room: roomArr });
					try {
						const db = await getMongoDbConnection();
						const collection = db.collection(COLLECTION.users);
						const result = await collection.findOneAndUpdate(
							{ "contact.phone": socket.payload.phoneNumber },
							{ "$inc": { "question.solved": 1 } });
						await collection.findOneAndUpdate(
							{ "contact.phone": roomArr[roomIndex]["techAttend"] },
							{ "$inc": { "question.solved": 1 } });
					} catch (error) {

					}
					await deleteTechFromRoom(roomArr[roomIndex]["room"]);
				} else {
					io.to(roomArr[roomIndex].room).emit('techyClickSolvedRoom', { room: roomArr });
				}
			})

			socket.on("techyClickSolvedRoom", async (data) => {
				if (data.solvedCount) {
					const { roomArr, roomIndex } = await solvedController(data, socket.payload)
					console.log(roomArr, "==========================updatedRoom2=======================");
					io.to(roomArr[roomIndex].room).emit('solvedRoom', { room: roomArr });
					try {
						const db = await getMongoDbConnection();
						const collection = db.collection(COLLECTION.users);
						const result = await collection.findOneAndUpdate(
							{ "contact.phone": socket.payload.phoneNumber },
							{ "$inc": { "question.solved": 1 } });
						console.log(result, "==========================result Solved=======================");
						await collection.findOneAndUpdate(
							{ "contact.phone": roomArr[roomIndex]["techAttend"] },
							{ "$inc": { "question.solved": 1 } });
					} catch (error) {

					}
					await deleteTechFromRoom(roomArr[roomIndex]["room"]);
				}
				// const room = await solvedController(data, socket.payload)
				// console.log(room, "==========================updatedRoom=======================");
				// io.emit('solvedRoom', { room: room });
			})

			//view more old messages, adding 50 numbers to each request

			socket.on("viewMoreOldMessages", async (data) => {
				console.log(data, "==============view more old messages data");
				if (data.room) {
					const db = await getMongoDbConnection();
					const collection = db.collection(COLLECTION.messages);
					const messages = await collection.find({ room: data.room.room }).sort({ _id: -1 }).limit(10 * data.count).toArray();
					io.to(data.room.room).emit("viewMoreOldMessages", messages.reverse())
				} else {
					const room = await userFindRoom(socket.payload.phoneNumber)
					console.log(room);
					const db = await getMongoDbConnection();
					const collection = db.collection(COLLECTION.messages);
					const messages = await collection.find({ room: room.room }).sort({ _id: -1 }).limit(50 * data.count).toArray();
					io.to(room.room).emit("view_more_old_message_for_user", messages.reverse())
				}
			})

		});


	createMongoDbConnection();
	app.use('/', router);
	server.listen(port, () => {
		console.log('Server Running on port ' + port);
	});
} catch (err) {
	// Error Handler function goes here
	console.log(err);
}
